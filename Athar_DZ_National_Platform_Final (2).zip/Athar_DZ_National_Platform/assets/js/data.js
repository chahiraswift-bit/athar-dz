/* ==========================================================================
   ATHAR DZ (أَثَـر DZ) — National Production Dataset (69 Wilayas) & Storage
   ========================================================================== */

const ATHAR_STORAGE_KEY = "athar_dz_production_v3";

const ALGERIA_69_WILAYAS = [
  { code: "01", ar: "01 - أدرار", fr: "01 - Adrar", en: "01 - Adrar" },
  { code: "02", ar: "02 - الشلف", fr: "02 - Chlef", en: "02 - Chlef" },
  { code: "03", ar: "03 - الأغواط", fr: "03 - Laghouat", en: "03 - Laghouat" },
  { code: "04", ar: "04 - أم البواقي", fr: "04 - Oum El Bouaghi", en: "04 - Oum El Bouaghi" },
  { code: "05", ar: "05 - باتنة", fr: "05 - Batna", en: "05 - Batna" },
  { code: "06", ar: "06 - بجاية", fr: "06 - Béjaïa", en: "06 - Bejaia" },
  { code: "07", ar: "07 - بسكرة", fr: "07 - Biskra", en: "07 - Biskra" },
  { code: "08", ar: "08 - بشار", fr: "08 - Béchar", en: "08 - Bechar" },
  { code: "09", ar: "09 - البليدة", fr: "09 - Blida", en: "09 - Blida" },
  { code: "10", ar: "10 - البويرة", fr: "10 - Bouira", en: "10 - Bouira" },
  { code: "11", ar: "11 - تمنراست", fr: "11 - Tamanrasset", en: "11 - Tamanrasset" },
  { code: "12", ar: "12 - تبسة", fr: "12 - Tébessa", en: "12 - Tebessa" },
  { code: "13", ar: "13 - تلمسان", fr: "13 - Tlemcen", en: "13 - Tlemcen" },
  { code: "14", ar: "14 - تيارت", fr: "14 - Tiaret", en: "14 - Tiaret" },
  { code: "15", ar: "15 - تيزي وزو", fr: "15 - Tizi Ouzou", en: "15 - Tizi Ouzou" },
  { code: "16", ar: "16 - الجزائر العاصمة", fr: "16 - Alger", en: "16 - Algiers" },
  { code: "17", ar: "17 - الجلفة", fr: "17 - Djelfa", en: "17 - Djelfa" },
  { code: "18", ar: "18 - جيجل", fr: "18 - Jijel", en: "18 - Jijel" },
  { code: "19", ar: "19 - سطيف", fr: "19 - Sétif", en: "19 - Setif" },
  { code: "20", ar: "20 - سعيدة", fr: "20 - Saïda", en: "20 - Saida" },
  { code: "21", ar: "21 - سكيكدة", fr: "21 - Skikda", en: "21 - Skikda" },
  { code: "22", ar: "22 - سيدي بلعباس", fr: "22 - Sidi Bel Abbès", en: "22 - Sidi Bel Abbes" },
  { code: "23", ar: "23 - عنابة", fr: "23 - Annaba", en: "23 - Annaba" },
  { code: "24", ar: "24 - قالمة", fr: "24 - Guelma", en: "24 - Guelma" },
  { code: "25", ar: "25 - قسنطينة", fr: "25 - Constantine", en: "25 - Constantine" },
  { code: "26", ar: "26 - المدية", fr: "26 - Médéa", en: "26 - Medea" },
  { code: "27", ar: "27 - مستغانم", fr: "27 - Mostaganem", en: "27 - Mostaganem" },
  { code: "28", ar: "28 - المسيلة", fr: "28 - M'Sila", en: "28 - M'Sila" },
  { code: "29", ar: "29 - معسكر", fr: "29 - Mascara", en: "29 - Mascara" },
  { code: "30", ar: "30 - ورقلة", fr: "30 - Ouargla", en: "30 - Ouargla" },
  { code: "31", ar: "31 - وهران", fr: "31 - Oran", en: "31 - Oran" },
  { code: "32", ar: "32 - البيض", fr: "32 - El Bayadh", en: "32 - El Bayadh" },
  { code: "33", ar: "33 - إليزي", fr: "33 - Illizi", en: "33 - Illizi" },
  { code: "34", ar: "34 - برج بوعريريج", fr: "34 - Bordj Bou Arréridj", en: "34 - Bordj Bou Arreridj" },
  { code: "35", ar: "35 - بومرداس", fr: "35 - Boumerdès", en: "35 - Boumerdes" },
  { code: "36", ar: "36 - الطارف", fr: "36 - El Tarf", en: "36 - El Tarf" },
  { code: "37", ar: "37 - تندوف", fr: "37 - Tindouf", en: "37 - Tindouf" },
  { code: "38", ar: "38 - تيسمسيلت", fr: "38 - Tissemsilt", en: "38 - Tissemsilt" },
  { code: "39", ar: "39 - الوادي", fr: "39 - El Oued", en: "39 - El Oued" },
  { code: "40", ar: "40 - خنشلة", fr: "40 - Khenchela", en: "40 - Khenchela" },
  { code: "41", ar: "41 - سوق أهراس", fr: "41 - Souk Ahras", en: "41 - Souk Ahras" },
  { code: "42", ar: "42 - تيبازة", fr: "42 - Tipaza", en: "42 - Tipaza" },
  { code: "43", ar: "43 - ميلة", fr: "43 - Mila", en: "43 - Mila" },
  { code: "44", ar: "44 - عين الدفلى", fr: "44 - Aïn Defla", en: "44 - Ain Defla" },
  { code: "45", ar: "45 - النعامة", fr: "45 - Naâma", en: "45 - Naama" },
  { code: "46", ar: "46 - عين تموشنت", fr: "46 - Aïn Témouchent", en: "46 - Ain Temouchent" },
  { code: "47", ar: "47 - غرداية", fr: "47 - Ghardaïa", en: "47 - Ghardaia" },
  { code: "48", ar: "48 - غليزان", fr: "48 - Relizane", en: "48 - Relizane" },
  { code: "49", ar: "49 - تيميمون", fr: "49 - Timimoun", en: "49 - Timimoun" },
  { code: "50", ar: "50 - برج باجي مختار", fr: "50 - Bordj Badji Mokhtar", en: "50 - Bordj Badji Mokhtar" },
  { code: "51", ar: "51 - أولاد جلال", fr: "51 - Ouled Djellal", en: "51 - Ouled Djellal" },
  { code: "52", ar: "52 - بني عباس", fr: "52 - Béni Abbès", en: "52 - Beni Abbes" },
  { code: "53", ar: "53 - عين صالح", fr: "53 - In Salah", en: "53 - In Salah" },
  { code: "54", ar: "54 - عين قزام", fr: "54 - In Guezzam", en: "54 - In Guezzam" },
  { code: "55", ar: "55 - تقرت", fr: "55 - Touggourt", en: "55 - Touggourt" },
  { code: "56", ar: "56 - جانت", fr: "56 - Djanet", en: "56 - Djanet" },
  { code: "57", ar: "57 - المغير", fr: "57 - El M'Ghair", en: "57 - El M'Ghair" },
  { code: "58", ar: "58 - المنيعة", fr: "58 - El Meniaa", en: "58 - El Meniaa" },
  { code: "59", ar: "59 - أفلو", fr: "59 - Aflou", en: "59 - Aflou" },
  { code: "60", ar: "60 - بريكة", fr: "60 - Barika", en: "60 - Barika" },
  { code: "61", ar: "61 - القنطرة", fr: "61 - El Kantara", en: "61 - El Kantara" },
  { code: "62", ar: "62 - بئر العاتر", fr: "62 - Bir El Ater", en: "62 - Bir El Ater" },
  { code: "63", ar: "63 - العريشة", fr: "63 - El Aricha", en: "63 - El Aricha" },
  { code: "64", ar: "64 - قصر الشلالة", fr: "64 - Ksar Chellala", en: "64 - Ksar Chellala" },
  { code: "65", ar: "65 - عين وسارة", fr: "65 - Aïn Oussera", en: "65 - Ain Oussera" },
  { code: "66", ar: "66 - مسعد", fr: "66 - Messaad", en: "66 - Messaad" },
  { code: "67", ar: "67 - قصر البخاري", fr: "67 - Ksar El Boukhari", en: "67 - Ksar El Boukhari" },
  { code: "68", ar: "68 - بوسعادة", fr: "68 - Bou Saâda", en: "68 - Bou Saada" },
  { code: "69", ar: "69 - الأبيض سيدي الشيخ", fr: "69 - El Abiodh Sidi Cheikh", en: "69 - El Abiodh Sidi Cheikh" }
];

const DEFAULT_ATHAR_STATE = {
  lang: "ar",
  points: 0,
  user: {
    loggedIn: false,
    role: "visitor", // 'visitor' | 'artisan' | 'admin'
    subscribed: false,
    plan: "pro",
    name: "",
    email: "",
    phone: "",
    wilayaCode: "16"
  },
  accounts: [],
  bookings: [],
  orders: [],
  inquiries: [],
  sites: [
    {
      id: "DZ-CIRTA-25",
      wilayaCode: "25",
      cat: "heritage",
      image: "assets/images/constantine-bridge.jpg",
      wilaya: { ar: "25 - قسنطينة", fr: "25 - Constantine", en: "25 - Constantine" },
      catLabel: { ar: "معلم أثري", fr: "Monument Historique", en: "Historical Monument" },
      title: {
        ar: "جسر سيدي مسيد المعلق وقصر أحمد باي — قسنطينة",
        fr: "Pont Suspendu Sidi M’Cid & Palais Ahmed Bey — Constantine",
        en: "Sidi M’Cid Suspension Bridge & Ahmed Bey Palace — Constantine"
      },
      desc: {
        ar: "جولة ثقافية عبر الجسور المعلقة فوق أخدود وادي الرمال واكتشاف الزخارف الجدارية النادرة في قصر أحمد باي.",
        fr: "Parcours culturel sur les ponts suspendus au-dessus des gorges du Rhumel et visite du Palais Ahmed Bey.",
        en: "Cultural walk across the suspension bridges over the Rhumel gorge and guided tour of Ahmed Bey Palace."
      },
      schedule: {
        ar: "يومياً • 09:30 صباحاً - 17:00 مساءً",
        fr: "Tous les jours • 09h30 - 17h00",
        en: "Daily • 09:30 AM - 05:00 PM"
      },
      price: 550,
      reward: 190,
      visited: false,
      quiz: {
        question: {
          ar: "ما اسم الوادي الصخري العميق الذي تعبره جسور مدينة قسنطينة المعلقة؟",
          fr: "Quel oued traverse les gorges profondes sous les ponts suspendus de Constantine ?",
          en: "Which deep river gorge runs beneath Constantine’s famous suspension bridges?"
        },
        options: {
          ar: ["وادي الرمال", "وادي الشلف", "وادي ميزاب"],
          fr: ["L’Oued Rhumel", "L’Oued Chéliff", "L’Oued M’zab"],
          en: ["Rhumel River Gorge", "Chelif River", "M'zab Valley"]
        },
        answerIdx: 0
      }
    },
    {
      id: "DZ-MZAB-47",
      wilayaCode: "47",
      cat: "heritage",
      image: "assets/images/ghardaia-mzab.jpg",
      wilaya: { ar: "47 - غرداية", fr: "47 - Ghardaïa", en: "47 - Ghardaia" },
      catLabel: { ar: "تراث عالمي", fr: "Patrimoine Mondial", en: "World Heritage" },
      title: {
        ar: "قصر بني يزقن وسوق المزاب التراثي — غرداية",
        fr: "Ksar de Beni Isguen & Marché Traditionnel — Ghardaïa",
        en: "Ksar of Beni Isguen & Heritage Market — Ghardaia"
      },
      desc: {
        ar: "استكشاف العمارة الطينية الأصيلة لوادي ميزاب المصنف في اليونسكو وحضور المزاد التقليدي للحرف.",
        fr: "Découverte de l’architecture oasienne millénaire de la vallée du M’zab classée UNESCO et de son marché.",
        en: "Explore millennial earthen architecture in the UNESCO-listed M’zab Valley and its traditional craft auction."
      },
      schedule: {
        ar: "السبت إلى الخميس • 09:00 صباحاً - 17:30 مساءً",
        fr: "Samedi au Jeudi • 09h00 - 17h30",
        en: "Saturday to Thursday • 09:00 AM - 05:30 PM"
      },
      price: 650,
      reward: 220,
      visited: false,
      quiz: {
        question: {
          ar: "في أي سنة صُنّف وادي ميزاب بولاية غرداية ضمن قائمة التراث العالمي لليونسكو؟",
          fr: "En quelle année la vallée du M’zab (Ghardaïa) a-t-elle été classée au patrimoine mondial de l’UNESCO ?",
          en: "In what year was the M’zab Valley in Ghardaia inscribed on the UNESCO World Heritage List?"
        },
        options: {
          ar: ["1982", "1999", "2010"],
          fr: ["1982", "1999", "2010"],
          en: ["1982", "1999", "2010"]
        },
        answerIdx: 0
      }
    },
    {
      id: "DZ-CASBAH-16",
      wilayaCode: "16",
      cat: "heritage",
      image: "assets/images/casbah.jpg",
      wilaya: { ar: "16 - الجزائر العاصمة", fr: "16 - Alger", en: "16 - Algiers" },
      catLabel: { ar: "معلم أثري", fr: "Monument Historique", en: "Historical Monument" },
      title: {
        ar: "قصبة الجزائر العتيقة — مسار القصور والحرف",
        fr: "La Casbah d’Alger — Circuit des Palais & Artisans",
        en: "Casbah of Algiers — Palaces & Artisans Trail"
      },
      desc: {
        ar: "جولة ثقافية موجهة لاكتشاف العمارة التاريخية، الدويرات، وورشات الحرفيين التقليديين المصنفة في اليونسكو.",
        fr: "Visite guidée à la découverte de l’architecture historique, des palais et des ateliers d’artisans classés UNESCO.",
        en: "Guided cultural tour exploring UNESCO-listed historic architecture, palaces, and traditional artisan workshops."
      },
      schedule: {
        ar: "يومياً • 10:00 صباحاً - 16:00 مساءً",
        fr: "Tous les jours • 10h00 - 16h00",
        en: "Daily • 10:00 AM - 04:00 PM"
      },
      price: 600,
      reward: 150,
      visited: false,
      quiz: {
        question: {
          ar: "في أي سنة أُدرجت قصبة الجزائر ضمن قائمة التراث العالمي لليونسكو؟",
          fr: "En quelle année la Casbah d’Alger a-t-elle été inscrite au patrimoine mondial de l’UNESCO ?",
          en: "In what year was the Casbah of Algiers inscribed on the UNESCO World Heritage List?"
        },
        options: {
          ar: ["1992", "2005", "1978"],
          fr: ["1992", "2005", "1978"],
          en: ["1992", "2005", "1978"]
        },
        answerIdx: 0
      }
    },
    {
      id: "DZ-TIMGAD-05",
      wilayaCode: "05",
      cat: "heritage",
      image: "assets/images/timgad.jpg",
      wilaya: { ar: "05 - باتنة", fr: "05 - Batna", en: "05 - Batna" },
      catLabel: { ar: "معلم أثري", fr: "Site Archéologique", en: "Archaeological Site" },
      title: {
        ar: "مدينة تيمقاد الأثرية (ثاموقادي)",
        fr: "Cité Antique de Timgad (Thamugadi)",
        en: "Ancient Roman City of Timgad (Thamugadi)"
      },
      desc: {
        ar: "استكشاف المسرح الروماني وقوس تراجان والشوارع المرصوفة في قلب الأوراس مع دليل تفاعلي وختم ذهبي.",
        fr: "Exploration du théâtre romain, de l’Arc de Trajan et des voies pavées au cœur des Aurès avec timbre doré.",
        en: "Explore the Roman theater, Arch of Trajan, and paved streets in the heart of the Aurès with a golden stamp."
      },
      schedule: {
        ar: "يومياً • 09:00 صباحاً - 17:00 مساءً",
        fr: "Tous les jours • 09h00 - 17h00",
        en: "Daily • 09:00 AM - 05:00 PM"
      },
      price: 500,
      reward: 200,
      visited: false,
      quiz: {
        question: {
          ar: "ما هو المعلم الشهير الذي يميز مدخل مدينة تيمقاد الأثرية في باتنة؟",
          fr: "Quel monument emblématique marque l’entrée de la cité antique de Timgad ?",
          en: "Which iconic monument marks the entrance of the ancient city of Timgad?"
        },
        options: {
          ar: ["قوس تراجان", "قلعة بني حماد", "ضريح إيمدغاسن"],
          fr: ["L’Arc de Trajan", "La Kalâa des Béni Hammad", "Le Tombeau d’Imedghassen"],
          en: ["The Arch of Trajan", "Kalâa of Beni Hammad", "Tomb of Imedghassen"]
        },
        answerIdx: 0
      }
    },
    {
      id: "DZ-MECHOUAR-13",
      wilayaCode: "13",
      cat: "museum",
      image: "assets/images/mechouar.jpg",
      wilaya: { ar: "13 - تلمسان", fr: "13 - Tlemcen", en: "13 - Tlemcen" },
      catLabel: { ar: "متحف وقصر", fr: "Palais & Musée", en: "Palace & Museum" },
      title: {
        ar: "قصر المشور الملكي ومتحف الفن والتاريخ",
        fr: "Palais Royal El Mechouar & Musée d’Art",
        en: "El Mechouar Royal Palace & Art Museum"
      },
      desc: {
        ar: "اكتشاف روائع الزليج التلمساني، النقش على الجبس، والشدة التلمسانية المصنفة كتراث ثقافي إنساني.",
        fr: "Découverte des chefs-d’œuvre du zellige tlemcénien, du stuc ciselé et de la Chedda classée au patrimoine.",
        en: "Discover masterpieces of Tlemcen zellige tilework, carved stucco, and the UNESCO-listed Chedda attire."
      },
      schedule: {
        ar: "الثلاثاء إلى الأحد • 09:30 صباحاً - 16:30 مساءً",
        fr: "Mardi au Dimanche • 09h30 - 16h30",
        en: "Tuesday to Sunday • 09:30 AM - 04:30 PM"
      },
      price: 450,
      reward: 180,
      visited: false,
      quiz: {
        question: {
          ar: "أي سلالة تاريخية اتخذت من قصر المشور بتلمسان مقراً لحكمها؟",
          fr: "Quelle dynastie historique a établi sa capitale au Palais El Mechouar de Tlemcen ?",
          en: "Which historical dynasty established its royal seat at El Mechouar Palace in Tlemcen?"
        },
        options: {
          ar: ["الدولة الزيانية", "الدولة الحمادية", "الدولة الرستمية"],
          fr: ["Les Zianides", "Les Hammadides", "Les Rostémides"],
          en: ["The Zianids", "The Hammadids", "The Rustamids"]
        },
        answerIdx: 0
      }
    },
    {
      id: "DZ-TNA-16",
      wilayaCode: "16",
      cat: "theater",
      image: "assets/images/theater.jpg",
      wilaya: { ar: "16 - الجزائر العاصمة", fr: "16 - Alger", en: "16 - Algiers" },
      catLabel: { ar: "مسرح وفنون حية", fr: "Théâtre & Arts Vivants", en: "Theater & Live Arts" },
      title: {
        ar: "سهرة فنية وتراثية — المسرح الوطني محي الدين بشطارزي",
        fr: "Soirée Artistique — Théâtre National Mahieddine Bachtarzi",
        en: "Cultural Performance — Mahieddine Bachtarzi National Theater"
      },
      desc: {
        ar: "أمسية فنية تجمع بين المسرح الجزائري والموسيقى الأندلسية والتراثية مع حجز مقعد وتذكرة رقمية فورية.",
        fr: "Soirée artistique mêlant théâtre algérien et musique patrimoniale avec réservation et e-billet QR.",
        en: "Artistic evening blending Algerian theater and heritage music with instant QR digital seat ticketing."
      },
      schedule: {
        ar: "الخميس والجمعة • 19:00 مساءً",
        fr: "Jeudi & Vendredi • 19h00",
        en: "Thursday & Friday • 07:00 PM"
      },
      price: 800,
      reward: 160,
      visited: false,
      quiz: {
        question: {
          ar: "باسم أي رائد من رواد المسرح والموسيقى الجزائرية سُمّي المسرح الوطني بالعاصمة؟",
          fr: "Du nom de quel pionnier du théâtre algérien le Théâtre National d’Alger porte-t-il le nom ?",
          en: "Which pioneer of Algerian theater is the National Theater in Algiers named after?"
        },
        options: {
          ar: ["محي الدين بشطارزي", "كاتب ياسين", "عبد القادر علولة"],
          fr: ["Mahieddine Bachtarzi", "Kateb Yacine", "Abdelkader Alloula"],
          en: ["Mahieddine Bachtarzi", "Kateb Yacine", "Abdelkader Alloula"]
        },
        answerIdx: 0
      }
    },
    {
      id: "DZ-BOUSAADA-68",
      wilayaCode: "68",
      cat: "museum",
      image: "assets/images/artisan-workshop.jpg",
      wilaya: { ar: "68 - بوسعادة", fr: "68 - Bou Saâda", en: "68 - Bou Saada" },
      catLabel: { ar: "متحف وتراث واحي", fr: "Musée & Patrimoine Oasien", en: "Museum & Oasis Heritage" },
      title: {
        ar: "متحف نصر الدين ديني وقصر بوسعادة العتيق",
        fr: "Musée Nasreddine Dinet & Ksar de Bou Saâda",
        en: "Nasreddine Dinet Museum & Historic Ksar of Bou Saada"
      },
      desc: {
        ar: "رحلة ثقافية في بوابة الصحراء لاكتشاف لوحات نصر الدين ديني، الصناعات التقليدية البوسعادية، والقصور العتيقة.",
        fr: "Escapade culturelle à la porte du désert pour découvrir les œuvres de Nasreddine Dinet et l’artisanat local.",
        en: "Cultural journey at the gateway to the Sahara discovering Nasreddine Dinet artworks and local crafts."
      },
      schedule: {
        ar: "يومياً • 09:30 صباحاً - 17:00 مساءً",
        fr: "Tous les jours • 09h30 - 17h00",
        en: "Daily • 09:30 AM - 05:00 PM"
      },
      price: 400,
      reward: 190,
      visited: false,
      quiz: {
        question: {
          ar: "بماذا تُلقّب مدينة بوسعادة (الولاية 68) في الثقافة والسياحة الجزائرية؟",
          fr: "Quel surnom célèbre porte la ville de Bou Saâda (Wilaya 68) dans la culture algérienne ?",
          en: "What famous nickname does the city of Bou Saada (Wilaya 68) hold in Algerian culture?"
        },
        options: {
          ar: ["مدينة السعادة وبوابة الصحراء", "مدينة الجسور المعلقة", "جوهرة الساورة"],
          fr: ["La Cité du Bonheur et Porte du Désert", "La Ville des Ponts Suspendus", "La Perle de la Saoura"],
          en: ["City of Happiness & Gateway to the Sahara", "City of Suspended Bridges", "Pearl of Saoura"]
        },
        answerIdx: 0
      }
    },
    {
      id: "DZ-KANTARA-61",
      wilayaCode: "61",
      cat: "heritage",
      image: "assets/images/emblem.jpg",
      wilaya: { ar: "61 - القنطرة", fr: "61 - El Kantara", en: "61 - El Kantara" },
      catLabel: { ar: "معلم أثري وطبيعي", fr: "Site Historique & Naturel", en: "Historical & Natural Site" },
      title: {
        ar: "فم الصحراء والجسر الروماني العتيق — القنطرة",
        fr: "Bouche du Sahara & Pont Romain — El Kantara",
        en: "Mouth of the Sahara & Ancient Roman Bridge — El Kantara"
      },
      desc: {
        ar: "استكشاف المضيق الصخري التاريخي والجسر الروماني وواحات النخيل والمتحف الأثري في ولاية القنطرة.",
        fr: "Découverte des gorges rocheuses historiques, du pont romain, des palmeraies et du musée d’El Kantara.",
        en: "Explore the historic rocky gorge, Roman bridge, palm oases, and archaeological museum in El Kantara."
      },
      schedule: {
        ar: "يومياً • 09:00 صباحاً - 17:30 مساءً",
        fr: "Tous les jours • 09h00 - 17h30",
        en: "Daily • 09:00 AM - 05:30 PM"
      },
      price: 450,
      reward: 210,
      visited: false,
      quiz: {
        question: {
          ar: "بماذا يُعرف المضيق الصخري التاريخي في ولاية القنطرة (الولاية 61)؟",
          fr: "Comment appelle-t-on le célèbre défilé rocheux d’El Kantara (Wilaya 61) ?",
          en: "What is the famous historic rocky gorge in El Kantara (Wilaya 61) known as?"
        },
        options: {
          ar: ["فم الصحراء", "وادي ميزاب", "هضبة الهقار"],
          fr: ["La Bouche du Sahara", "La Vallée du M’zab", "Le Plateau du Hoggar"],
          en: ["The Mouth of the Sahara", "M'zab Valley", "Hoggar Plateau"]
        },
        answerIdx: 0
      }
    }
  ],
  products: [
    {
      id: "CERT-DZ-1301",
      wilayaCode: "13",
      image: "assets/images/chedda-tlemcen.jpg",
      wilaya: { ar: "13 - تلمسان", fr: "13 - Tlemcen", en: "13 - Tlemcen" },
      artisan: {
        ar: "دار الزي الملكي الزياني — تلمسان",
        fr: "Maison du Costume Royal Zianide — Tlemcen",
        en: "Zianide Royal Attire House — Tlemcen"
      },
      name: {
        ar: "قفطان وتاج الشدة التلمسانية المطرز بالذهب واللؤلؤ",
        fr: "Caftan & Couronne de la Chedda de Tlemcen Brodés d’Or",
        en: "Royal Chedda of Tlemcen Gold & Pearl Embroidered Caftan"
      },
      desc: {
        ar: "تحفة تراثية مصنفة في اليونسكو تجمع بين القفطان المخملي المطرز بالفتلة وعقود الجوهر والتاج المخروطي الذهبي.",
        fr: "Chef-d’œuvre patrimonial classé UNESCO associant caftan en velours brodé d’or, colliers de perles et couronne.",
        en: "UNESCO-inscribed heritage masterpiece combining gold-embroidered velvet caftan, pearl necklaces, and golden crown."
      },
      material: {
        ar: "مخمل ملكي، خيوط ذهبية، ولؤلؤ تقليدي 100%",
        fr: "Velours royal, fil d’or et perles traditionnelles 100%",
        en: "Royal velvet, gold thread, and traditional pearls 100%"
      },
      price: 24000,
      pointsCost: 600
    },
    {
      id: "CERT-DZ-2509",
      wilayaCode: "25",
      image: "assets/images/brass-constantine.jpg",
      wilaya: { ar: "25 - قسنطينة", fr: "25 - Constantine", en: "25 - Constantine" },
      artisan: {
        ar: "ورشة نقاشي النحاس العتيقة — قسنطينة",
        fr: "Atelier des Dinandiers — Constantine",
        en: "Constantine Master Coppersmiths Atelier"
      },
      name: {
        ar: "صينية وإبريق نحاس قسنطيني منقوش يدوياً",
        fr: "Plateau & Théière en Cuivre Ciselé de Constantine",
        en: "Hand-Engraved Constantine Brass Tray & Teapot Set"
      },
      desc: {
        ar: "أوانٍ نحاسية أصيلة منقوشة بالإزميل اليدوي بزخارف هندسية ونباتية قسنطينية عريقة.",
        fr: "Pièces de dinanderie authentiques ciselées à la main aux motifs géométriques constantinois.",
        en: "Authentic hand-chiseled brassware featuring traditional Constantine geometric and floral engravings."
      },
      material: {
        ar: "نحاس أصفر وأحمر خالص منقوش يدوياً 100%",
        fr: "Laiton et cuivre massif ciselé à la main 100%",
        en: "100% solid hand-engraved brass and copper"
      },
      price: 8900,
      pointsCost: 420
    },
    {
      id: "CERT-DZ-9023",
      wilayaCode: "16",
      image: "assets/images/karakou.jpg",
      wilaya: { ar: "16 - الجزائر العاصمة", fr: "16 - Alger", en: "16 - Algiers" },
      artisan: {
        ar: "دار الأصالة للتصميم والطرز التقليدي",
        fr: "Maison El Assala Couture & Broderie",
        en: "Maison El Assala Traditional Couture"
      },
      name: {
        ar: "كاراكو عاصمي مخملي مطرز بالفتلة الذهبية",
        fr: "Karakou Algérois en Velours Brodé à la Fetla",
        en: "Algiers Emerald Velvet Karakou with Gold Fetla"
      },
      desc: {
        ar: "قطعة فاخرة من المخمل الأخضر الزمردي مطرزة يدوياً بخيوط الفتلة الذهبية وفق التقاليد العاصمية الأصيلة.",
        fr: "Pièce d’exception en velours vert émeraude brodée à la main au fil d’or selon le savoir-faire algérois.",
        en: "Exquisite emerald green velvet jacket hand-embroidered with golden Fetla threads in authentic Algiers tradition."
      },
      material: {
        ar: "مخمل ملكي وخيوط فتلة ذهبية 100%",
        fr: "Velours royal et fil d’or Fetla 100%",
        en: "Royal velvet and 100% golden Fetla thread"
      },
      price: 18500,
      pointsCost: 500
    },
    {
      id: "CERT-DZ-8841",
      wilayaCode: "05",
      image: "assets/images/pottery.jpg",
      wilaya: { ar: "05 - باتنة", fr: "05 - Batna", en: "05 - Batna" },
      artisan: {
        ar: "ورشة الأوراس وجرجرة للفخار التقليدي",
        fr: "Atelier des Aurès & Djurdjura Poterie",
        en: "Aurès & Djurdjura Traditional Pottery Workshop"
      },
      name: {
        ar: "طقم أواني فخارية مزخرفة برموز أمازيغية",
        fr: "Service en Poterie Artisanale aux Motifs Amazighs",
        en: "Handcrafted Clay Pottery Set with Amazigh Motifs"
      },
      desc: {
        ar: "أوانٍ طينية مشكّلة ومزخرفة يدوياً بأصباغ طبيعية مستخرجة من تربة الجبال الجزائرية.",
        fr: "Poteries façonnées et peintes à la main avec des pigments naturels issus des montagnes algériennes.",
        en: "Hand-molded clay vessels painted with natural mineral pigments from Algerian mountains."
      },
      material: {
        ar: "طين طبيعي وأصباغ معدنية ونباتية 100%",
        fr: "Argile naturelle et pigments minéraux 100%",
        en: "100% natural clay and mineral pigments"
      },
      price: 3400,
      pointsCost: 250
    },
    {
      id: "CERT-DZ-7719",
      wilayaCode: "15",
      image: "assets/images/jewelry.jpg",
      wilaya: { ar: "15 - تيزي وزو", fr: "15 - Tizi Ouzou", en: "15 - Tizi Ouzou" },
      artisan: {
        ar: "تعاونية حرفيي الفضة — بني يني",
        fr: "Coopérative des Bijoutiers de Beni Yenni",
        en: "Beni Yenni Silversmiths Cooperative"
      },
      name: {
        ar: "حلي فضي تقليدي مرصع بالمرجان والمينا",
        fr: "Parure en Argent Serti de Corail & Émail",
        en: "Traditional Silver Jewelry with Coral & Enamel"
      },
      desc: {
        ar: "تحفة صياغة تقليدية من الفضة الخالصة مرصعة بالمرجان المتوسطي وألوان المينا الأصفر والأخضر.",
        fr: "Chef-d’œuvre d’orfèvrerie en argent massif serti de corail méditerranéen et d’émail traditionnel.",
        en: "Masterpiece of pure silver craftsmanship inlaid with Mediterranean coral and traditional enamel."
      },
      material: {
        ar: "فضة خالصة عيار 925 ومرجان طبيعي",
        fr: "Argent massif 925 et corail naturel",
        en: "925 sterling silver and natural coral"
      },
      price: 7200,
      pointsCost: 400
    },
    {
      id: "CERT-DZ-6410",
      wilayaCode: "40",
      image: "assets/images/babar-carpet.jpg",
      wilaya: { ar: "40 - خنشلة", fr: "40 - Khenchela", en: "40 - Khenchela" },
      artisan: {
        ar: "دار النسيج الأوراسي — بابار",
        fr: "Maison du Tissage Aurésien — Babar",
        en: "Aurès Weaving House — Babar"
      },
      name: {
        ar: "زربية بابار الأوراسية المنسوجة يدوياً",
        fr: "Tapis Traditionnel de Babar Tissé à la Main",
        en: "Handwoven Babar Traditional Carpet"
      },
      desc: {
        ar: "نسيج صوفي أصيل يحمل رموزاً هندسية عريقة تعبّر عن تاريخ منطقة الأوراس وعراقتها.",
        fr: "Tissage en laine pure orné de symboles géométriques ancestraux de la région des Aurès.",
        en: "Pure wool weaving adorned with ancestral geometric symbols from the Aurès region."
      },
      material: {
        ar: "صوف طبيعي مغزول ومصبوغ يدوياً",
        fr: "Laine naturelle filée et teinte à la main",
        en: "100% hand-spun and naturally dyed wool"
      },
      price: 14000,
      pointsCost: 550
    }
  ],
  challenges: [
    {
      id: "GAME-01",
      bonus: 120,
      completed: false,
      title: {
        ar: "لغز العمارة والزليج الجزائري",
        fr: "Énigme de l’Architecture & du Zellige",
        en: "Algerian Architecture & Zellige Riddle"
      },
      desc: {
        ar: "أجب عن التحدي الثقافي الخاص بفنون العمارة في تلمسان والقصبة لربح 120 نقطة إضافية.",
        fr: "Résolvez le défi culturel sur l’architecture de Tlemcen et de la Casbah pour gagner +120 pts.",
        en: "Solve the cultural challenge on Tlemcen and Casbah architecture to earn +120 bonus points."
      },
      question: {
        ar: "ما هو العنصر الزخرفي الهندسي الذي تشتهر به جدران قصر المشور بتلمسان والقصبة؟",
        fr: "Quel élément décoratif géométrique orne les murs du Palais El Mechouar et de la Casbah ?",
        en: "Which geometric decorative tilework adorns the walls of El Mechouar Palace and the Casbah?"
      },
      options: {
        ar: ["الزليج الخزفي متعدد الألوان", "الرخام الإيطالي الحديث", "الزجاج الملون الصناعي"],
        fr: ["Le Zellige en céramique polychrome", "Le marbre industriel moderne", "Le verre synthétique"],
        en: ["Polychrome ceramic Zellige tilework", "Modern industrial marble", "Synthetic stained glass"]
      },
      answerIdx: 0
    },
    {
      id: "GAME-02",
      bonus: 150,
      completed: false,
      title: {
        ar: "تحدي كنوز الحرف اليدوية (69 ولاية)",
        fr: "Défi des Trésors de l’Artisanat (69 Wilayas)",
        en: "Handicraft Treasures Challenge (69 Wilayas)"
      },
      desc: {
        ar: "اختبر معرفتك بالحرف الجزائرية الأصيلة واجمع نقاطاً لاستبدالها بهدايا من الحرفيين.",
        fr: "Testez vos connaissances sur l’artisanat algérien et cumulez des points cadeaux.",
        en: "Test your knowledge of authentic Algerian crafts and earn points toward artisan gifts."
      },
      question: {
        ar: "بأي حرفة تقليدية عريقة تشتهر منطقة بني يني في ولاية تيزي وزو؟",
        fr: "Par quel savoir-faire artisanal ancestral la région de Beni Yenni (Tizi Ouzou) est-elle célèbre ?",
        en: "Which ancestral craft is the Beni Yenni region in Tizi Ouzou famous for?"
      },
      options: {
        ar: ["صناعة الحلي الفضية المرصعة بالمرجان", "صناعة السفن الخشبية", "صناعة الساعات"],
        fr: ["La bijouterie en argent sertie de corail", "La construction navale", "L’horlogerie"],
        en: ["Silver jewelry inlaid with coral", "Wooden shipbuilding", "Watchmaking"]
      },
      answerIdx: 0
    },
    {
      id: "GAME-03",
      bonus: 180,
      completed: false,
      title: {
        ar: "مسار الحضارات عبر 69 ولاية جزائرية",
        fr: "Parcours des Civilisations à travers 69 Wilayas",
        en: "Trail of Civilizations Across 69 Algerian Wilayas"
      },
      desc: {
        ar: "تحدي المستكشفين الكبار حول المواقع الأثرية الجزائرية المصنفة عالمياً.",
        fr: "Défi des grands explorateurs sur les sites archéologiques algériens classés.",
        en: "Grand explorers challenge on Algeria’s world-renowned archaeological sites."
      },
      question: {
        ar: "كم موقعاً ثقافياً وطبيعياً جزائرياً مصنفاً ضمن قائمة التراث العالمي لليونسكو؟",
        fr: "Combien de sites culturels et naturels algériens sont classés au patrimoine mondial de l’UNESCO ?",
        en: "How many Algerian cultural and natural sites are inscribed on the UNESCO World Heritage List?"
      },
      options: {
        ar: ["7 مواقع مصنفة عالمياً", "موقعان فقط", "موقع واحد"],
        fr: ["7 sites classés au patrimoine mondial", "2 sites uniquement", "1 seul site"],
        en: ["7 UNESCO World Heritage sites", "Only 2 sites", "1 single site"]
      },
      answerIdx: 0
    }
  ],
  wilayaStats: [],
  approvals: []
};

function loadAtharState() {
  try {
    const raw = localStorage.getItem(ATHAR_STORAGE_KEY);
    if (!raw) {
      saveAtharState(DEFAULT_ATHAR_STATE);
      return JSON.parse(JSON.stringify(DEFAULT_ATHAR_STATE));
    }
    return JSON.parse(raw);
  } catch (e) {
    return JSON.parse(JSON.stringify(DEFAULT_ATHAR_STATE));
  }
}

function saveAtharState(state) {
  try {
    localStorage.setItem(ATHAR_STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    // Ignore storage quota errors
  }
}

function getWilayaNameByCode(code, lang) {
  const found = ALGERIA_69_WILAYAS.find((w) => w.code === code);
  if (!found) return code;
  return found[lang] || found.ar;
}
