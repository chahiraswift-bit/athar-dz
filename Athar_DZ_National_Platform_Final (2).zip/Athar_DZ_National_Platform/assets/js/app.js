/* ==========================================================================
   ATHAR DZ (أَثَـر DZ) — Shared Application Logic, 69-Wilaya Engine & Booking
   ========================================================================== */

let atharState = loadAtharState();

function t(key) {
  const lang = atharState.lang || "ar";
  return (ATHAR_I18N[lang] && ATHAR_I18N[lang][key]) || (ATHAR_I18N["ar"] && ATHAR_I18N["ar"][key]) || key;
}

function loc(obj) {
  if (!obj) return "";
  if (typeof obj === "string") return obj;
  const lang = atharState.lang || "ar";
  return obj[lang] || obj["ar"] || obj["fr"] || obj["en"] || "";
}

function showToast(keyOrText, isRaw = false) {
  const el = document.getElementById("global-toast");
  if (!el) return;
  el.textContent = isRaw ? keyOrText : t(keyOrText);
  el.classList.add("show");
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => {
    el.classList.remove("show");
  }, 4000);
}

function generateQrSvg(seed) {
  let rects = "";
  for (let r = 0; r < 7; r++) {
    for (let c = 0; c < 7; c++) {
      const isCorner = (r < 2 && c < 2) || (r < 2 && c > 4) || (r > 4 && c < 2);
      const codeVal = (seed.charCodeAt((r + c) % seed.length) + r * 5 + c * 11) % 3;
      if (isCorner || codeVal === 0) {
        const fill = !isCorner && (r + c) % 4 === 0 ? "#D4AF37" : "#064E3B";
        rects += `<rect x="${c * 14 + 4}" y="${r * 14 + 4}" width="11" height="11" rx="2" fill="${fill}" />`;
      }
    }
  }
  return `<svg width="106" height="106" viewBox="0 0 106 106" aria-label="QR Code">${rects}</svg>`;
}

function populateAllWilayaSelects() {
  const lang = atharState.lang || "ar";
  document.querySelectorAll("select[data-wilaya-select]").forEach((sel) => {
    const prevVal = sel.value;
    const includeAll = sel.getAttribute("data-include-all") === "true";
    let html = "";
    if (includeAll) {
      html += `<option value="all">${t("filter_wilaya_all")}</option>`;
    }
    html += ALGERIA_69_WILAYAS.map(
      (w) => `<option value="${w.code}">${w[lang] || w.ar}</option>`
    ).join("");
    sel.innerHTML = html;
    if (prevVal && Array.from(sel.options).some((o) => o.value === prevVal)) {
      sel.value = prevVal;
    } else if (!includeAll) {
      sel.value = atharState.user?.wilayaCode || "16";
    }
  });
}


function enforcePageAccess() {
  const currentPage = document.body.getAttribute("data-page");
  const u = atharState.user || { loggedIn: false };

  if (currentPage === "visitor") {
    if (!u.loggedIn || u.role !== "visitor") {
      window.location.replace("login.html?role=visitor&required=1");
      return false;
    }
  } else if (currentPage === "artisan") {
    if (!u.loggedIn || u.role !== "artisan" || !u.subscribed) {
      window.location.replace("login.html?role=artisan&required=1");
      return false;
    }
  } else if (currentPage === "admin") {
    if (!u.loggedIn || u.role !== "admin") {
      window.location.replace("login.html?role=admin&required=1");
      return false;
    }
  }
  return true;
}

function globalLogout() {
  atharState.user = {
    loggedIn: false,
    role: "visitor",
    subscribed: false,
    plan: "pro",
    name: "",
    email: "",
    phone: "",
    wilayaCode: "16"
  };
  saveAtharState(atharState);
  showToast("toast_logged_out");
  const currentPage = document.body.getAttribute("data-page");
  if (["visitor", "artisan", "admin"].includes(currentPage)) {
    setTimeout(() => {
      window.location.href = "index.html";
    }, 300);
  } else {
    applyTranslations();
  }
}

function updateRoleBasedNavigation() {
  const u = atharState.user || { loggedIn: false };
  const navVisitor = document.querySelector('.nav-item[data-nav="visitor"]');
  const navArtisan = document.querySelector('.nav-item[data-nav="artisan"]');
  const navAdmin = document.querySelector('.nav-item[data-nav="admin"]');
  const headerLogoutBtn = document.getElementById("header-logout-btn");

  if (navVisitor) {
    navVisitor.classList.toggle("hidden", !(u.loggedIn && u.role === "visitor"));
  }
  if (navArtisan) {
    navArtisan.classList.toggle("hidden", !(u.loggedIn && u.role === "artisan" && u.subscribed));
  }
  if (navAdmin) {
    navAdmin.classList.toggle("hidden", !(u.loggedIn && u.role === "admin"));
  }
  if (headerLogoutBtn) {
    headerLogoutBtn.classList.toggle("hidden", !u.loggedIn);
  }
}

function applyTranslations() {
  const lang = atharState.lang || "ar";
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";

  document.querySelectorAll(".lang-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.lang === lang);
  });

  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    if (key) el.textContent = t(key);
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.getAttribute("data-i18n-placeholder");
    if (key) el.setAttribute("placeholder", t(key));
  });

  populateAllWilayaSelects();

  const ptsEl = document.getElementById("header-points");
  if (ptsEl) ptsEl.textContent = atharState.points;

  const authBadgeEl = document.getElementById("header-auth-label");
  if (authBadgeEl) {
    if (atharState.user && atharState.user.loggedIn && atharState.user.name) {
      const roleKey =
        atharState.user.role === "admin"
          ? "role_admin_badge"
          : atharState.user.role === "artisan"
          ? "role_artisan_badge"
          : "role_visitor_badge";
      authBadgeEl.textContent = `${atharState.user.name} (${t(roleKey)})`;
    } else {
      authBadgeEl.textContent = t("btn_login_portal");
    }
  }

  updateRoleBasedNavigation();

  const currentPage = document.body.getAttribute("data-page");
  if (currentPage) {
    const titleKey = "page_title_" + currentPage;
    const translatedTitle = t(titleKey);
    if (translatedTitle && translatedTitle !== titleKey) {
      document.title = translatedTitle;
    }
  }
  document.querySelectorAll(".nav-item").forEach((link) => {
    link.classList.toggle("active", link.getAttribute("data-nav") === currentPage);
  });

  if (typeof window.renderPageContent === "function") {
    window.renderPageContent();
  }
}

function setLanguage(newLang) {
  if (!["ar", "fr", "en"].includes(newLang)) return;
  atharState.lang = newLang;
  saveAtharState(atharState);
  applyTranslations();
}

/* ==================== SHARED MODALS ==================== */

function openModal(badgeText, titleText, subText, qrHtml, extraHtml) {
  const overlay = document.getElementById("global-modal");
  if (!overlay) return;
  document.getElementById("g-modal-badge").textContent = badgeText;
  document.getElementById("g-modal-title").textContent = titleText;
  document.getElementById("g-modal-sub").textContent = subText;

  const qrBox = document.getElementById("g-modal-qr");
  if (qrHtml) {
    qrBox.innerHTML = qrHtml;
    qrBox.classList.remove("hidden");
  } else {
    qrBox.innerHTML = "";
    qrBox.classList.add("hidden");
  }

  document.getElementById("g-modal-extra").innerHTML = extraHtml || "";
  overlay.classList.add("open");
}

function closeGlobalModal(e) {
  if (!e || e.target.id === "global-modal") {
    const overlay = document.getElementById("global-modal");
    if (overlay) overlay.classList.remove("open");
  }
}

/* ==================== REAL EVENT & ACTIVITY BOOKING FLOW ==================== */

function openBookingModal(siteId) {
  const site = atharState.sites.find((s) => s.id === siteId);
  if (!site) return;

  const defaultName = atharState.user?.loggedIn ? atharState.user.name : "";
  const defaultPhone = atharState.user?.phone || "";
  const tomorrow = new Date(Date.now() + 86400000).toISOString().split("T")[0];

  const formHtml = `
    <form onsubmit="submitEventBooking(event, '${site.id}')" style="text-align:start;margin-top:12px;">
      <div class="form-field">
        <label>${t("lbl_bk_name")}</label>
        <input type="text" id="bk-name" class="input-control" required value="${defaultName}" placeholder="${t("ph_bk_name")}" />
      </div>
      <div class="form-field">
        <label>${t("lbl_bk_phone")}</label>
        <input type="tel" id="bk-phone" class="input-control" required value="${defaultPhone}" placeholder="${t("ph_bk_phone")}" />
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
        <div class="form-field">
          <label>${t("lbl_bk_date")}</label>
          <input type="date" id="bk-date" class="input-control" required value="${tomorrow}" min="${tomorrow}" />
        </div>
        <div class="form-field">
          <label>${t("lbl_bk_qty")}</label>
          <input type="number" id="bk-qty" class="input-control" required min="1" max="10" value="1" oninput="updateBookingTotal(${site.price}, ${site.reward})" />
        </div>
      </div>
      <div class="form-field">
        <label>${t("lbl_bk_slot")}</label>
        <select id="bk-slot" class="select-control" style="width:100%;">
          <option value="morning">${t("slot_morning")}</option>
          <option value="afternoon">${t("slot_afternoon")}</option>
          <option value="evening">${t("slot_evening")}</option>
        </select>
      </div>
      <div class="form-field">
        <label>${t("lbl_bk_payment")}</label>
        <select id="bk-payment" class="select-control" style="width:100%;">
          <option value="edahabia">${t("pay_edahabia")}</option>
          <option value="cib">${t("pay_cib")}</option>
          <option value="onsite">${t("pay_onsite")}</option>
        </select>
      </div>
      <div class="booking-summary-box">
        <div style="display:flex;justify-content:space-between;margin-bottom:4px;">
          <span>${t("lbl_bk_total")}</span>
          <strong style="color:var(--emerald);" id="bk-total-val">${site.price} ${t("currency_dzd")}</strong>
        </div>
        <div style="display:flex;justify-content:space-between;">
          <span>${t("lbl_bk_earn")}</span>
          <strong style="color:var(--terracotta);" id="bk-earn-val">+${site.reward} ${t("pts_unit")}</strong>
        </div>
      </div>
      <button type="submit" class="btn btn-emerald" style="width:100%;">${t("btn_confirm_booking")}</button>
    </form>
  `;

  openModal(
    t("booking_modal_badge"),
    loc(site.title),
    `${getWilayaNameByCode(site.wilayaCode, atharState.lang)} • ${site.price} ${t("currency_dzd")}`,
    null,
    formHtml
  );
}

function updateBookingTotal(unitPrice, unitReward) {
  const qty = Math.max(1, Math.min(10, parseInt(document.getElementById("bk-qty")?.value || "1", 10)));
  const totEl = document.getElementById("bk-total-val");
  const earnEl = document.getElementById("bk-earn-val");
  if (totEl) totEl.textContent = `${unitPrice * qty} ${t("currency_dzd")}`;
  if (earnEl) earnEl.textContent = `+${unitReward * qty} ${t("pts_unit")}`;
}

function submitEventBooking(e, siteId) {
  e.preventDefault();
  const site = atharState.sites.find((s) => s.id === siteId);
  if (!site) return;

  const visitorName = document.getElementById("bk-name").value.trim();
  const phone = document.getElementById("bk-phone").value.trim();
  const visitDate = document.getElementById("bk-date").value;
  const slotKey = document.getElementById("bk-slot").value;
  const qty = Math.max(1, Math.min(10, parseInt(document.getElementById("bk-qty").value, 10) || 1));
  const paymentKey = document.getElementById("bk-payment").value;

  const bookingId = "BKG-DZ-" + Math.floor(100000 + Math.random() * 900000);
  const totalDzd = site.price * qty;

  const bookingRecord = {
    bookingId,
    siteId: site.id,
    visitorName,
    phone,
    visitDate,
    slotKey,
    quantity: qty,
    totalDzd,
    paymentKey,
    createdAt: new Date().toISOString().split("T")[0]
  };

  atharState.bookings.unshift(bookingRecord);
  saveAtharState(atharState);
  applyTranslations();
  showToast("toast_booked");
  showBookingTicket(bookingId);
}

function showBookingTicket(bookingId) {
  const bk = atharState.bookings.find((b) => b.bookingId === bookingId);
  if (!bk) return;
  const site = atharState.sites.find((s) => s.id === bk.siteId);
  const siteTitle = site ? loc(site.title) : bk.siteId;
  const wilayaText = site ? getWilayaNameByCode(site.wilayaCode, atharState.lang) : "";
  const slotLabel = t("slot_" + bk.slotKey);
  const payLabel = t("pay_" + bk.paymentKey);

  const ticketHtml = `
    <div class="booking-summary-box">
      <div style="margin-bottom:4px;"><strong>${t("bk_holder_lbl")}</strong> ${bk.visitorName} (${bk.phone})</div>
      <div style="margin-bottom:4px;"><strong>${t("bk_date_lbl")}</strong> ${bk.visitDate} • ${slotLabel}</div>
      <div style="margin-bottom:4px;"><strong>${t("bk_qty_lbl")}</strong> ${bk.quantity}</div>
      <div><strong>${t("bk_paid_lbl")}</strong> ${bk.totalDzd} ${t("currency_dzd")} (${payLabel})</div>
    </div>
    <p style="font-size:0.8rem;color:var(--slate);margin-bottom:10px;">${t("modal_ticket_note")}</p>
    <button type="button" class="btn btn-gold btn-sm" style="width:100%;" onclick="window.print()">${t("btn_print_ticket")}</button>
  `;

  openModal(
    t("booking_confirmed_badge"),
    siteTitle,
    `${wilayaText} • ${bk.bookingId}`,
    `${generateQrSvg(bk.bookingId)}<span style="font-size:0.7rem;font-family:monospace;margin-top:5px;">${bk.bookingId}</span>`,
    ticketHtml
  );
}

/* ==================== VISIT GAMES & CHALLENGES ==================== */

function handleOpenVisitGame(siteId) {
  const site = atharState.sites.find((s) => s.id === siteId);
  if (!site || site.visited) return;

  const qText = loc(site.quiz.question);
  const opts = loc(site.quiz.options);

  const optionsHtml = opts
    .map(
      (opt, idx) =>
        `<button type="button" class="quiz-option" onclick="submitVisitAnswer('${site.id}', ${idx})">${idx + 1}. ${opt}</button>`
    )
    .join("");

  openModal(
    t("modal_quiz_badge"),
    loc(site.title),
    `${getWilayaNameByCode(site.wilayaCode, atharState.lang)} • +${site.reward} ${t("pts_unit")}`,
    null,
    `<div style="text-align:start;margin-top:12px;">
      <p style="font-size:0.8rem;color:var(--terracotta);font-weight:700;margin-bottom:8px;">${t("modal_quiz_hint")}</p>
      <p style="font-size:0.92rem;font-weight:800;margin-bottom:12px;color:var(--charcoal);">${qText}</p>
      ${optionsHtml}
    </div>`
  );
}

function submitVisitAnswer(siteId, chosenIdx) {
  const site = atharState.sites.find((s) => s.id === siteId);
  if (!site) return;

  if (chosenIdx === site.quiz.answerIdx) {
    site.visited = true;
    atharState.points += site.reward;
    saveAtharState(atharState);
    closeGlobalModal();
    applyTranslations();
    showToast("toast_quiz_win");
  } else {
    showToast("toast_quiz_wrong");
  }
}

function handleOpenChallengeGame(challengeId) {
  const ch = atharState.challenges.find((c) => c.id === challengeId);
  if (!ch || ch.completed) return;

  const qText = loc(ch.question);
  const opts = loc(ch.options);

  const optionsHtml = opts
    .map(
      (opt, idx) =>
        `<button type="button" class="quiz-option" onclick="submitChallengeAnswer('${ch.id}', ${idx})">${idx + 1}. ${opt}</button>`
    )
    .join("");

  openModal(
    t("modal_quiz_badge"),
    loc(ch.title),
    `+${ch.bonus} ${t("pts_unit")}`,
    null,
    `<div style="text-align:start;margin-top:12px;">
      <p style="font-size:0.8rem;color:var(--terracotta);font-weight:700;margin-bottom:8px;">${t("modal_quiz_hint")}</p>
      <p style="font-size:0.92rem;font-weight:800;margin-bottom:12px;color:var(--charcoal);">${qText}</p>
      ${optionsHtml}
    </div>`
  );
}

function submitChallengeAnswer(challengeId, chosenIdx) {
  const ch = atharState.challenges.find((c) => c.id === challengeId);
  if (!ch) return;

  if (chosenIdx === ch.answerIdx) {
    ch.completed = true;
    atharState.points += ch.bonus;
    saveAtharState(atharState);
    closeGlobalModal();
    applyTranslations();
    showToast("toast_quiz_win");
  } else {
    showToast("toast_quiz_wrong");
  }
}

/* ==================== ARTISAN CERTIFICATES, DIRECT ORDERS & POINTS REDEMPTION ==================== */

function handleOpenCertificate(prodId) {
  const prod = atharState.products.find((p) => p.id === prodId);
  if (!prod) return;

  openModal(
    t("modal_cert_badge"),
    loc(prod.name),
    `${loc(prod.artisan)} (${getWilayaNameByCode(prod.wilayaCode, atharState.lang)})`,
    `${generateQrSvg(prod.id)}<span style="font-size:0.7rem;font-family:monospace;margin-top:5px;">${prod.id}</span>`,
    `<div style="background:var(--gold-light);border:1.5px solid var(--gold);border-radius:13px;padding:13px;text-align:start;font-size:0.82rem;">
      <div><strong>${t("modal_cert_material")}</strong> ${loc(prod.material)}</div>
      <div style="margin-top:6px;color:var(--emerald);font-weight:700;">${t("modal_cert_verified")}</div>
    </div>`
  );
}

function openCraftOrderModal(prodId) {
  const prod = atharState.products.find((p) => p.id === prodId);
  if (!prod) return;

  const defaultName = atharState.user?.loggedIn ? atharState.user.name : "";
  const defaultPhone = atharState.user?.phone || "";
  const defaultWilaya = atharState.user?.wilayaCode || "16";
  const lang = atharState.lang || "ar";

  const wilayaOptions = ALGERIA_69_WILAYAS.map(
    (w) => `<option value="${w.code}" ${w.code === defaultWilaya ? "selected" : ""}>${w[lang] || w.ar}</option>`
  ).join("");

  const orderHtml = `
    <form onsubmit="submitCraftOrder(event, '${prod.id}')" style="text-align:start;margin-top:12px;">
      <div class="form-field">
        <label>${t("lbl_bk_name")}</label>
        <input type="text" id="ord-name" class="input-control" required value="${defaultName}" placeholder="${t("ph_bk_name")}" />
      </div>
      <div class="form-field">
        <label>${t("lbl_bk_phone")}</label>
        <input type="tel" id="ord-phone" class="input-control" required value="${defaultPhone}" placeholder="${t("ph_bk_phone")}" />
      </div>
      <div class="form-field">
        <label>${t("lbl_wilaya")}</label>
        <select id="ord-wilaya" class="select-control" style="width:100%;">${wilayaOptions}</select>
      </div>
      <div class="form-field">
        <label>${t("lbl_ord_address")}</label>
        <input type="text" id="ord-address" class="input-control" required placeholder="${t("ph_ord_address")}" />
      </div>
      <div class="form-field">
        <label>${t("lbl_bk_payment")}</label>
        <select id="ord-payment" class="select-control" style="width:100%;">
          <option value="edahabia">${t("pay_edahabia")}</option>
          <option value="cib">${t("pay_cib")}</option>
          <option value="onsite">${t("pay_onsite")}</option>
        </select>
      </div>
      <div class="booking-summary-box">
        <div style="display:flex;justify-content:space-between;">
          <span>${t("lbl_bk_total")}</span>
          <strong style="color:var(--emerald);">${prod.price} ${t("currency_dzd")}</strong>
        </div>
      </div>
      <button type="submit" class="btn btn-terracotta" style="width:100%;">${t("btn_confirm_order")}</button>
    </form>
  `;

  openModal(
    t("craft_order_badge"),
    loc(prod.name),
    `${loc(prod.artisan)} • ${prod.id}`,
    null,
    orderHtml
  );
}

function submitCraftOrder(e, prodId) {
  e.preventDefault();
  const prod = atharState.products.find((p) => p.id === prodId);
  if (!prod) return;

  const orderId = "ORD-DZ-" + Math.floor(100000 + Math.random() * 900000);
  atharState.orders.unshift({
    orderId,
    prodId: prod.id,
    type: "direct",
    buyerName: document.getElementById("ord-name").value.trim(),
    phone: document.getElementById("ord-phone").value.trim(),
    wilayaCode: document.getElementById("ord-wilaya").value,
    address: document.getElementById("ord-address").value.trim(),
    priceDzd: prod.price,
    amountText: `${prod.price} ${t("currency_dzd")}`,
    createdAt: new Date().toISOString().split("T")[0]
  });

  saveAtharState(atharState);
  closeGlobalModal();
  applyTranslations();
  showToast("toast_order_placed");
}

function handleRedeemProduct(prodId) {
  const prod = atharState.products.find((p) => p.id === prodId);
  if (!prod) return;

  if (atharState.points < prod.pointsCost) {
    showToast("toast_insufficient");
    return;
  }

  atharState.points -= prod.pointsCost;
  const orderId = "GFT-DZ-" + Math.floor(100000 + Math.random() * 900000);
  atharState.orders.unshift({
    orderId,
    prodId: prod.id,
    type: "points",
    buyerName: atharState.user?.loggedIn ? atharState.user.name : "Athar Member",
    phone: atharState.user?.phone || "",
    wilayaCode: atharState.user?.wilayaCode || "16",
    address: "",
    amountText: `${prod.pointsCost} ${t("pts_unit")}`,
    createdAt: new Date().toISOString().split("T")[0]
  });

  saveAtharState(atharState);
  applyTranslations();
  showToast("toast_redeemed");
}

document.addEventListener("DOMContentLoaded", () => {
  if (!enforcePageAccess()) return;
  applyTranslations();
});
